
#ifndef _GATT_DB_H_
#define _GATT_DB_H_

#include "lsm6ds3.h"

#define X_OFFSET 200
#define Y_OFFSET 50
#define Z_OFFSET 1000

/** 
 * @brief Number of application services
 */
#define NUMBER_OF_APPLICATION_SERVICES (2)
   
/** 
 * @brief Structure containing acceleration value of each axis.
 */
typedef struct {
  int32_t AXIS_X;
  int32_t AXIS_Y;
  int32_t AXIS_Z;
} AxesRaw_t;


typedef struct __attribute__((packed)) {
    uint16_t year;   // 2 bytes for the year
    uint8_t month;   // 1 byte for the month
    uint8_t day;     // 1 byte for the day
    uint8_t hour;    // 1 byte for the hour
    uint8_t minute;  // 1 byte for the minute
    uint8_t second;  // 1 byte for the second
} date_time_data_t;

enum {
  ACCELERATION_SERVICE_INDEX = 0,  
  ENVIRONMENTAL_SERVICE_INDEX = 1,
  DATE_TIME_SERVICE_INDEX = 2
};

IMU_6AXES_StatusTypeDef GetAccAxesRaw (AxesRaw_t * acceleration_data);
void GetFreeFallStatus(void);

tBleStatus Add_Acc_Service(void);
tBleStatus Add_DT_Service(void);
void Read_Request_CB(uint16_t handle);
tBleStatus Free_Fall_Notify(void);
tBleStatus Acc_Update(AxesRaw_t *data);

tBleStatus Add_Environmental_Sensor_Service(void);

extern volatile uint8_t request_free_fall_notify;

extern uint8_t Services_Max_Attribute_Records[];
#endif /* _GATT_DB_H_ */
